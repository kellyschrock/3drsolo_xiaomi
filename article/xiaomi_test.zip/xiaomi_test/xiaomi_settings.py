#! /usr/bin/env python
# encoding: windows-1250
#
# Res Andy 

camaddr = "10.1.1.12"
camport = 7878
